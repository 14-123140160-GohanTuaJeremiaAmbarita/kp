import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Check, ChevronDown, Brain, Zap, Layers } from 'lucide-react';

export interface ModelItem {
  id: string;
  name: string;
  desc: string;
  icon: string;
  category: 'synthesis' | 'reasoning' | 'budget';
  cost: 'Free' | 'Ultra Low' | 'Low' | 'Standard' | 'Premium' | 'Dynamic';
  details: string;
}

export const MODEL_WHITELIST: ModelItem[] = [
  // Tier 1: Synthesis
  { 
    id: 'openrouter-fusion', 
    name: 'OpenRouter Fusion', 
    desc: 'Parallel multi-model deliberation panel', 
    icon: '🌀', 
    category: 'synthesis', 
    cost: 'Dynamic', 
    details: 'Runs multiple models in parallel & deliberates for high accuracy. Best for complex SQL troubleshooting.' 
  },
  
  // Tier 2: Advanced Reasoning
  { 
    id: 'deepseek-v4-pro', 
    name: 'DeepSeek R1', 
    desc: 'Deep reasoning chain for logical validation', 
    icon: '🧠', 
    category: 'reasoning', 
    cost: 'Standard', 
    details: 'Full reasoning trace. Excellent at debugging database schemas & multi-join SELECTs.' 
  },
  { 
    id: 'claude', 
    name: 'Claude 3.5 Sonnet', 
    desc: 'Top-tier analytical overview & exact SQL logic', 
    icon: '🎭', 
    category: 'reasoning', 
    cost: 'Premium', 
    details: 'Very high precision, standard formatting, and descriptive human-friendly responses.' 
  },
  { 
    id: 'gemini-3.5-flash', 
    name: 'Gemini 3.5 Flash', 
    desc: 'Balanced speed, logic & multi-turn consistency', 
    icon: '✨', 
    category: 'reasoning', 
    cost: 'Standard', 
    details: 'Default model. Extremely fast execution with high schema alignment.' 
  },
  
  // Tier 3: Budget (sorted by price low-to-high)
  { 
    id: 'openrouter-free', 
    name: 'Auto Free Tier', 
    desc: 'Routes to available free models automatically', 
    icon: '🍃', 
    category: 'budget', 
    cost: 'Free', 
    details: 'Zero cost routing. Ideal for simple general chat queries and single table reports.' 
  },
  { 
    id: 'deepseek-v4-flash', 
    name: 'DeepSeek Chat (V3)', 
    desc: 'Extremely fast, low-cost core LLM', 
    icon: '⚡', 
    category: 'budget', 
    cost: 'Ultra Low', 
    details: 'Outstanding cost-to-performance ratio. Very fast responses.' 
  },
  { 
    id: 'qwen-coder', 
    name: 'Qwen 2.5 Coder 32B', 
    desc: 'Optimized specifically for SQL & script syntax', 
    icon: '💻', 
    category: 'budget', 
    cost: 'Low', 
    details: 'Alibaba\'s code specialist. Excellent parsing of database schemas.' 
  },
  { 
    id: 'openai', 
    name: 'GPT-4o mini', 
    desc: 'Fast, efficient, and versatile generalist', 
    icon: '🚀', 
    category: 'budget', 
    cost: 'Low', 
    details: 'OpenAI\'s lightweight model. Reliable and quick.' 
  },
  { 
    id: 'llama-3.3', 
    name: 'Llama 3.3 70B', 
    desc: 'High quality open weights model, budget-friendly', 
    icon: '🦙', 
    category: 'budget', 
    cost: 'Low', 
    details: 'Meta\'s robust large open weights model. Standard quality at low cost.' 
  }
];

interface ModelSelectorProps {
  selectedModel: string;
  setSelectedModel: (model: string) => void;
  theme?: 'light' | 'dark';
}

export default function ModelSelector({ selectedModel, setSelectedModel, theme }: ModelSelectorProps) {
  const isDark = theme === 'dark';
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown on click outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const activeModel = MODEL_WHITELIST.find((m) => m.id === selectedModel) || MODEL_WHITELIST[3];

  const getCostBadgeStyles = (cost: string) => {
    switch (cost) {
      case 'Free':
        return 'bg-emerald-500/10 text-emerald-500 dark:text-emerald-400 border border-emerald-500/20';
      case 'Ultra Low':
        return 'bg-sky-500/10 text-sky-500 dark:text-sky-400 border border-sky-500/20';
      case 'Low':
        return 'bg-blue-500/10 text-blue-500 dark:text-blue-400 border border-blue-500/20';
      case 'Standard':
        return 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20';
      case 'Premium':
        return 'bg-rose-500/10 text-rose-500 dark:text-rose-400 border border-rose-500/20';
      case 'Dynamic':
      default:
        return 'bg-purple-500/10 text-purple-500 dark:text-purple-400 border border-purple-500/20';
    }
  };

  const getCategoryHeader = (category: string) => {
    switch (category) {
      case 'synthesis':
        return { label: 'Enterprise Intelligence', icon: <Layers className="h-3 w-3 text-purple-500" /> };
      case 'reasoning':
        return { label: 'Advanced Reasoning & Logic', icon: <Brain className="h-3 w-3 text-amber-500" /> };
      case 'budget':
      default:
        return { label: 'Cost-Efficient & Free Tier', icon: <Zap className="h-3 w-3 text-sky-500" /> };
    }
  };

  // Group models by category
  const categories = ['synthesis', 'reasoning', 'budget'] as const;

  return (
    <div className="relative inline-block text-left" ref={dropdownRef}>
      {/* Dropdown Toggle Button */}
      <button
        id="model-selector-btn"
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className={`flex items-center space-x-1.5 rounded-lg border px-3 py-1.5 text-[10.5px] font-semibold tracking-wide transition-all duration-200 cursor-pointer shadow-sm select-none hover:scale-[1.01] active:scale-[0.99] ${
          isOpen
            ? 'border-blue-500 bg-blue-50/5 dark:bg-blue-950/10 ring-1 ring-blue-500'
            : isDark
            ? 'border-slate-800 bg-slate-900 text-slate-200 hover:bg-slate-850 hover:border-slate-700'
            : 'border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100 hover:border-slate-300'
        }`}
      >
        <span className="text-xs">{activeModel.icon}</span>
        <span>{activeModel.name}</span>
        <ChevronDown className={`h-3 w-3 text-slate-400 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {/* Popover List */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.95 }}
            transition={{ duration: 0.15, ease: 'easeOut' }}
            className={`absolute bottom-full left-0 z-50 mb-2 w-80 sm:w-96 rounded-xl border p-2.5 shadow-xl backdrop-blur-md max-h-[380px] overflow-y-auto custom-scrollbar ${
              isDark
                ? 'border-slate-800 bg-slate-950/95 shadow-black/60 text-slate-200'
                : 'border-slate-200/80 bg-white/95 shadow-slate-200/50 text-slate-800'
            }`}
          >
            <div className="space-y-3">
              {categories.map((cat) => {
                const filteredModels = MODEL_WHITELIST.filter((m) => m.category === cat);
                if (filteredModels.length === 0) return null;
                const header = getCategoryHeader(cat);

                return (
                  <div key={cat} className="space-y-1">
                    {/* Category Title */}
                    <div className="flex items-center space-x-1.5 px-2 py-1 text-[9.5px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                      {header.icon}
                      <span>{header.label}</span>
                    </div>

                    {/* Model Cards */}
                    <div className="space-y-1">
                      {filteredModels.map((model) => {
                        const isSelected = model.id === selectedModel;
                        return (
                          <button
                            key={model.id}
                            type="button"
                            onClick={() => {
                              setSelectedModel(model.id);
                              setIsOpen(false);
                            }}
                            className={`w-full text-left flex items-start space-x-2.5 rounded-lg p-2 transition duration-150 cursor-pointer ${
                              isSelected
                                ? isDark
                                  ? 'bg-blue-600/15 border border-blue-500/35 text-white'
                                  : 'bg-blue-500/10 border border-blue-500/20 text-blue-800'
                                : isDark
                                ? 'border border-transparent hover:bg-slate-900 text-slate-300 hover:text-slate-100'
                                : 'border border-transparent hover:bg-slate-50 text-slate-600 hover:text-slate-850'
                            }`}
                          >
                            {/* Icon Container */}
                            <div className="flex-shrink-0 text-base mt-0.5">{model.icon}</div>

                            {/* Text Info */}
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center justify-between">
                                <span className="text-[11px] font-semibold tracking-wide truncate">
                                  {model.name}
                                </span>
                                <span className={`text-[8.5px] font-bold px-1.5 py-0.5 rounded-md ${getCostBadgeStyles(model.cost)}`}>
                                  {model.cost}
                                </span>
                              </div>
                              <p className={`text-[9.5px] leading-relaxed mt-0.5 font-normal truncate ${
                                isSelected ? 'text-blue-600/70 dark:text-blue-300/70' : 'text-slate-500'
                              }`}>
                                {model.desc}
                              </p>
                              {isSelected && (
                                <p className="text-[9px] leading-relaxed mt-1 text-slate-400 dark:text-slate-550 italic font-mono border-t border-dashed border-slate-200 dark:border-slate-800/80 pt-1">
                                  {model.details}
                                </p>
                              )}
                            </div>

                            {/* Checkmark */}
                            {isSelected && (
                              <div className="flex-shrink-0 self-center">
                                <Check className={`h-3.5 w-3.5 ${isDark ? 'text-blue-400' : 'text-blue-600'}`} />
                              </div>
                            )}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
