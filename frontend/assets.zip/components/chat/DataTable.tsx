import React, { useState, useEffect } from 'react';

interface DataTableProps {
  jsonResult: string;
  theme?: 'light' | 'dark';
}

export default function DataTable({ jsonResult, theme = 'dark' }: DataTableProps) {
  const isDark = theme === 'dark';
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(25);

  // Reset page when new result arrives
  useEffect(() => {
    setCurrentPage(1);
  }, [jsonResult]);

  try {
    const data: any[] = JSON.parse(jsonResult);
    if (!Array.isArray(data) || data.length === 0) {
      return (
        <div className={`p-3 text-center text-[11px] transition-colors duration-300 ${
          isDark ? 'text-slate-500 bg-slate-950' : 'text-slate-400 bg-slate-50'
        }`}>
          Kueri berhasil dijalankan namun tidak mengembalikan baris data (Empty Set).
        </div>
      );
    }

    const headers = Object.keys(data[0]);
    const totalRows = data.length;
    const totalPages = Math.ceil(totalRows / pageSize);

    // Calculate dynamic paging slice
    const startIndex = (currentPage - 1) * pageSize;
    const endIndex = Math.min(startIndex + pageSize, totalRows);
    const displayedData = data.slice(startIndex, endIndex);

    return (
      <div className={`flex flex-col mt-4 mb-2 rounded-2xl overflow-hidden border shadow-sm transition-all duration-300 backdrop-blur-md ${
        isDark 
          ? 'bg-slate-900/60 border-slate-700/50 shadow-slate-900/50' 
          : 'bg-white/80 border-slate-200 shadow-slate-200/50'
      }`}>
        {/* Header / Title Area (Optional, but gives enterprise feel) */}
        <div className={`px-4 py-3 border-b flex justify-between items-center ${isDark ? 'border-slate-800/50' : 'border-slate-100'}`}>
          <div className="flex items-center space-x-2">
            <div className={`w-2 h-2 rounded-full ${totalRows > 0 ? 'bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]' : 'bg-rose-500'}`}></div>
            <span className={`text-xs font-semibold uppercase tracking-wider ${isDark ? 'text-slate-300' : 'text-slate-600'}`}>
              Data Explorer
            </span>
          </div>
          <div className={`text-[10px] font-medium px-2 py-1 rounded-full ${isDark ? 'bg-slate-800 text-slate-400' : 'bg-slate-100 text-slate-500'}`}>
            {totalRows} Baris Ditemukan
          </div>
        </div>

        <div className="overflow-x-auto w-full custom-scrollbar selection:bg-blue-500/20">
          <table className="w-full text-left border-collapse font-sans text-[11px]">
            <thead>
              <tr className={`${
                isDark ? 'bg-slate-800/30 text-slate-400' : 'bg-slate-50/50 text-slate-500'
              }`}>
                {headers.map((h, i) => (
                  <th key={i} className="px-4 py-3 font-semibold uppercase tracking-wider whitespace-nowrap border-b border-transparent">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {displayedData.map((row, rowIndex) => (
                <tr 
                  key={rowIndex} 
                  className={`border-b last:border-b-0 transition-colors duration-200 ${
                    isDark 
                      ? 'border-slate-800/40 hover:bg-slate-800/50 text-slate-300' 
                      : 'border-slate-100 hover:bg-slate-50 text-slate-700'
                  }`}
                >
                  {headers.map((h, colIndex) => (
                    <td key={colIndex} className="px-4 py-2.5 max-w-xs truncate">{String(row[h] ?? 'NULL')}</td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        
        {/* Pagination Navigation Footer */}
        <div className={`px-4 py-3 border-t flex flex-col sm:flex-row items-center justify-between gap-3 text-[11px] font-medium transition-colors duration-300 ${
          isDark ? 'bg-slate-900/40 border-slate-800/50 text-slate-400' : 'bg-slate-50 border-slate-200 text-slate-600'
        }`}>
          <div>
            Menampilkan <span className={`font-bold ${isDark ? 'text-slate-200' : 'text-slate-800'}`}>{totalRows > 0 ? startIndex + 1 : 0}</span> - <span className={`font-bold ${isDark ? 'text-slate-200' : 'text-slate-800'}`}>{endIndex}</span> dari <span className={`font-bold ${isDark ? 'text-slate-200' : 'text-slate-800'}`}>{totalRows}</span>
          </div>

          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2 hidden sm:flex">
              <span className="opacity-70">Baris/halaman:</span>
              <select
                value={pageSize}
                onChange={(e) => {
                  setPageSize(Number(e.target.value));
                  setCurrentPage(1);
                }}
                className={`px-2 py-1 rounded-md border text-[11px] font-semibold cursor-pointer outline-none focus:ring-2 focus:ring-blue-500/50 transition-all ${
                  isDark 
                    ? 'bg-slate-800 border-slate-700 text-slate-200' 
                    : 'bg-white border-slate-300 text-slate-700'
                }`}
              >
                <option value={10}>10</option>
                <option value={20}>20</option>
                <option value={25}>25</option>
                <option value={50}>50</option>
                <option value={100}>100</option>
              </select>
            </div>

            <div className="flex items-center space-x-1 bg-slate-500/10 rounded-lg p-1">
              <button
                onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                disabled={currentPage === 1}
                className={`px-3 py-1.5 rounded-md text-[11px] font-bold transition-all disabled:opacity-30 disabled:cursor-not-allowed ${
                  isDark 
                    ? 'text-slate-300 hover:bg-slate-700 hover:text-white' 
                    : 'text-slate-600 hover:bg-white hover:shadow-sm'
                }`}
              >
                Prev
              </button>
              <div className={`px-2 text-[10px] font-bold tracking-widest ${isDark ? 'text-slate-500' : 'text-slate-400'}`}>
                {currentPage} / {totalPages}
              </div>
              <button
                onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                disabled={currentPage === totalPages || totalPages === 0}
                className={`px-3 py-1.5 rounded-md text-[11px] font-bold transition-all disabled:opacity-30 disabled:cursor-not-allowed ${
                  isDark 
                    ? 'text-slate-300 hover:bg-slate-700 hover:text-white' 
                    : 'text-slate-600 hover:bg-white hover:shadow-sm'
                }`}
              >
                Next
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  } catch (err) {
    return (
      <div className={`p-4 mt-2 rounded-xl text-[12px] border transition-colors duration-300 ${
        isDark ? 'bg-rose-950/30 border-rose-900/50 text-rose-400' : 'bg-rose-50 border-rose-200 text-rose-600'
      }`}>
        <div className="font-bold mb-1">Kesalahan Format Data</div>
        <div className="font-mono text-[10px] opacity-80">{String(err)}</div>
      </div>
    );
  }
}

export { DataTable as SqlResultTable };

