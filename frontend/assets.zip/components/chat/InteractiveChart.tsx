import React, { useMemo } from 'react';
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer, CartesianGrid,
  PieChart, Pie, Cell
} from 'recharts';
import { motion } from 'motion/react';
import { BarChart3, PieChart as PieChartIcon } from 'lucide-react';

interface InteractiveChartProps {
  jsonResult: string;
  theme?: 'light' | 'dark';
}

const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#06b6d4', '#f97316'];

export default function InteractiveChart({ jsonResult, theme = 'dark' }: InteractiveChartProps) {
  const isDark = theme === 'dark';

  const chartData = useMemo(() => {
    try {
      const parsed = JSON.parse(jsonResult);
      if (!Array.isArray(parsed) || parsed.length === 0) return null;

      // Ambil kunci pertama (header)
      const keys = Object.keys(parsed[0]);
      if (keys.length < 2) return null; // Butuh minimal 2 kolom untuk memetakan label vs value

      // Cari kolom yang kemungkinan besar adalah label (string/varchar) dan value (number/int)
      let labelKey = keys[0];
      let valueKey = keys[1];

      // Heuristic sederhana: Cari kolom dengan nama seperti 'Total', 'Jumlah', 'Count'
      const possibleValueKeys = keys.filter(k => 
        k.toLowerCase().includes('total') || 
        k.toLowerCase().includes('jumlah') || 
        k.toLowerCase().includes('count') ||
        typeof parsed[0][k] === 'number'
      );

      if (possibleValueKeys.length > 0) {
        valueKey = possibleValueKeys[0];
        labelKey = keys.find(k => k !== valueKey) || keys[0];
      }

      // Pastikan valuenya berbentuk angka
      const formattedData = parsed.map(row => ({
        name: String(row[labelKey] || 'N/A'),
        value: Number(row[valueKey] || 0)
      }));

      // Jika valuenya nol semua atau NaN, jangan tampilkan grafik
      if (formattedData.every(d => isNaN(d.value) || d.value === 0)) {
        return null;
      }

      return {
        data: formattedData,
        labelKey,
        valueKey
      };
    } catch (e) {
      return null;
    }
  }, [jsonResult]);

  if (!chartData) return null;

  const { data, valueKey } = chartData;
  const isPie = data.length <= 5; // Gunakan Pie Chart jika kategorinya sedikit

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.95, y: 10 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      className={`mt-4 mb-2 rounded-2xl overflow-hidden border shadow-md transition-all duration-300 backdrop-blur-md ${
        isDark 
          ? 'bg-slate-900/60 border-slate-700/50 shadow-slate-900/50' 
          : 'bg-white/80 border-slate-200 shadow-slate-200/50'
      }`}
    >
      <div className={`flex justify-between items-center px-4 py-3 border-b ${isDark ? 'border-slate-800/50' : 'border-slate-100'}`}>
        <div className="flex items-center space-x-2">
          <div className={`p-1.5 rounded-lg ${isDark ? 'bg-blue-500/20' : 'bg-blue-100'}`}>
            {isPie ? <PieChartIcon className="h-4 w-4 text-blue-500" /> : <BarChart3 className="h-4 w-4 text-blue-500" />}
          </div>
          <h3 className={`text-xs font-bold uppercase tracking-widest ${isDark ? 'text-slate-200' : 'text-slate-700'}`}>
            Visualisasi: {valueKey}
          </h3>
        </div>
      </div>
      
      <div className="w-full h-64 p-2">
        <ResponsiveContainer width="100%" height="100%">
          {isPie ? (
            <PieChart>
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: isDark ? 'rgba(15, 23, 42, 0.9)' : 'rgba(255, 255, 255, 0.9)', 
                  backdropFilter: 'blur(8px)',
                  borderColor: isDark ? '#334155' : '#e2e8f0',
                  borderRadius: '12px',
                  color: isDark ? '#f8fafc' : '#0f172a',
                  fontSize: '12px',
                  fontWeight: 'bold',
                  boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1)'
                }}
                itemStyle={{ color: isDark ? '#f1f5f9' : '#0f172a', fontWeight: 'bold' }}
              />
              <Legend wrapperStyle={{ fontSize: '11px', fontWeight: '500', paddingTop: '10px' }} />
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                innerRadius={65}
                outerRadius={90}
                paddingAngle={4}
                dataKey="value"
                stroke="none"
              >
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} className="hover:opacity-80 transition-opacity duration-300 cursor-pointer" />
                ))}
              </Pie>
            </PieChart>
          ) : (
            <BarChart data={data} margin={{ top: 20, right: 20, left: -20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke={isDark ? '#334155' : '#e2e8f0'} vertical={false} opacity={0.5} />
              <XAxis 
                dataKey="name" 
                tick={{ fontSize: 10, fill: isDark ? '#94a3b8' : '#64748b', fontWeight: 500 }} 
                tickLine={false} 
                axisLine={false}
                dy={10}
              />
              <YAxis 
                tick={{ fontSize: 10, fill: isDark ? '#94a3b8' : '#64748b', fontWeight: 500 }} 
                tickLine={false} 
                axisLine={false}
                dx={-10}
              />
              <Tooltip
                cursor={{ fill: isDark ? 'rgba(51, 65, 85, 0.4)' : 'rgba(241, 245, 249, 0.6)' }}
                contentStyle={{ 
                  backgroundColor: isDark ? 'rgba(15, 23, 42, 0.9)' : 'rgba(255, 255, 255, 0.9)', 
                  backdropFilter: 'blur(8px)',
                  borderColor: isDark ? '#334155' : '#e2e8f0',
                  borderRadius: '12px',
                  color: isDark ? '#f8fafc' : '#0f172a',
                  fontSize: '12px',
                  fontWeight: 'bold',
                  boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1)'
                }}
              />
              <Bar dataKey="value" radius={[6, 6, 0, 0]} maxBarSize={50}>
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} className="hover:opacity-80 transition-opacity duration-300 cursor-pointer" />
                ))}
              </Bar>
            </BarChart>
          )}
        </ResponsiveContainer>
      </div>
    </motion.div>
  );
}
